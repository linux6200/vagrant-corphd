#!/bin/bash
#
# Copyright (c) 2014 EMC Corporation
#  All Rights Reserved
#

java -Dproperty.file=vplex_config.properties -jar vplex-simulators*.jar > vp.log 2>&1 &
