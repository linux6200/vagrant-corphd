import sys
import airspeed
import simdb
import simparam
import alias
import logutil
import sys
import os
import json
import fcntl
import atexit
# staff for zoneset

logger = logutil.getLogger('ciscosim')


# this is for get_vsan_zoneset
template_vsan = """
zoneset name $zoneset_name vsan $vsan_id
#foreach ($zone in $zones)
  zone name $zone.name vsan $zone.vsan_id
    #foreach ($member in $zone.members)##
    pwwn $member.pwwn.lower() $member.type $member.alias
    #end##
#end##
"""
template_zone = """
zone name $zone.name vsan $vsan_id
  #foreach ($member in $zone.members)##
  pwwn $member.pwwn.lower()
  #end##
"""

template_active = """
#foreach ($zone in $zones)##
  zone name $zone.name vsan $zone.vsan_id
    #foreach ($member in $zone.members)##
    pwwn $member.pwwn.lower() $member.alias
    #end##
#end##
"""

show_pwwn_zone_tmpl = """
pwwn $pwwn vsan $vsan_id
#foreach ($zone_name in $zone_names)
  zone $zone_name
#end
"""

show_zone_name_tmpl = """
zone name $zone.name vsan $vsan.id
#foreach ($member in $zone.members)
    pwwn $member.pwwn
#end
"""

def get_vsan_zoneset(vsan_id):
    logger.info("Get zonesets from get_vsan_zoneset()...")
    vsan_zonesets = simdb.get_zonesets()
    aliases = simdb.get_aliases()
    # find the vsan
    for vsan in vsan_zonesets:
        if vsan["id"] == vsan_id:

            # found vsan, show all zonesets within it
            for zoneset in vsan["zonesets"]:
                zones = zoneset["zones"]
                for zone in zones:
                    zone["vsan_id"] = vsan_id
                    if 'members' in zone:
                        for member in zone["members"]:
                            member["alias"] = alias.get_alias_by_pwwn(aliases, member["pwwn"])
                            if "type" not in member:
                                member["type"]  = ""
                nameSpace = {
                    'zones': zones,
                    'zoneset_name': zoneset['name'],
                    'vsan_id' : vsan_id
                }

                t = airspeed.Template(template_vsan)
                print t.merge(nameSpace)

def get_active_zoneset():
    logger.info("Get zonesets from get_active_zoneset()...")
    vsan_zonesets = simdb.get_zonesets()
    active_zones = []
    aliases = simdb.get_aliases()
    for vsan in vsan_zonesets:
        vsan_id = vsan["id"]
        for zoneset in vsan["zonesets"]:
            if zoneset["active"] == "true":
                print "zoneset name %s vsan %s" % (zoneset["name"], vsan_id),
                zones = zoneset["zones"]
                for zone in zones:
                    zone["vsan_id"] = vsan_id
                    for member in zone["members"]:
                        member["alias"] = alias.get_alias_by_pwwn(aliases, member["pwwn"])
                active_zones.append(zone)
                nameSpace = {'zones': zones}
                t = airspeed.Template(template_active)
                print t.merge(nameSpace)

def get_vsan_active_zoneset(id):
    logger.info("Get zonesets from get_vsan_active_zoneset()...")
    vsan_zonesets = simdb.get_zonesets()
    active_zones = []
    aliases = simdb.get_aliases()
    for vsan in vsan_zonesets:
        vsan_id = vsan["id"]
        if vsan_id == id:
            for zoneset in vsan["zonesets"]:
                if zoneset["active"] == "true":
                    print "zoneset name %s vsan %s" % (zoneset["name"], vsan_id),
                    zones = zoneset["zones"]
                    for zone in zones:
                        zone["vsan_id"] = vsan_id
                        for member in zone["members"]:
                            member["alias"] = alias.get_alias_by_pwwn(aliases, member["pwwn"])
                    active_zones.append(zone)
                    nameSpace = {'zones': zones}
                    t = airspeed.Template(template_active)
                    print t.merge(nameSpace)

def config_zoneset(name, vsanid):
    # dump zone params for member zone
    params = {'vsanid' : vsanid, 'zoneset' : name }
    simparam.dump(params)

def member_zone_to_zoneset(zname):
    logger.info("Get zonesets from member_zone_to_zoneset()...")

    params = simparam.load()

    vsans = simdb.get_zonesets()

    vsan = find_vsan(vsans, params['vsanid'])
    if vsan == None:
        print >> sys.stderr, "not found vsan %s" % vsanid
        sys.exit(-1)

    zoneset = find_zoneset(vsan, params['zoneset'])
    if zoneset == None:
        print >> sys.stderr, "not found zoneset. vsan is %s, zoneset is %s" \
        % (params['vsanid'], params['zoneset'])
        sys.exit(-1)

    zone = find_zone_by_name(vsan, zname)
    logger.info("memberzone found %s" % zone)
    if zone == None:
        print >> sys.stderr, "not found zone. vsan is %s, zone name is %s" \
        % (params['vsanid'], zname)
        sys.exit(-1)

    remove_zone_from_zset(vsan, zone)
    zoneset['zones'].append(zone)

    # write back to db
    logger.info("Write zonesets from member_zone_to_zoneset...")
    remove_zone_from_zset(vsan, zone)
    zoneset['zones'].append(zone)
    simdb.write_zonesets(vsans)
   

def activate_zoneset(name, vsanid):
    pass

def remove_zone_from_zset(vsan, zone):

    zname = zone['name']

    for zset in vsan['zonesets']:
        for z in zset['zones']:
            if z['name'] == zname:
                zset['zones'].remove(zone)
                break

    return

# functions for zone
template_zone_status = """
#foreach ($vsan_zone in $vsan_zones)##
VSAN: $vsan_zone.vsan_id default-zone: permit distribute: full Interop: default
    mode: basic merge-control: allow
    session: none
    hard-zoning: enabled broadcast: unsupported
Default zone:
    qos: none broadcast: unsupported ronly: unsupported
Full Zoning Database :
    DB size: 324 bytes
    Zonesets:$vsan_zone.full_zoneset_number  Zones:$vsan_zone.full_zones Aliases: 0
Active Zoning Database :
    DB size: 132 bytes
    Name: $vsan_zone.active_zoneset_name  Zonesets:1  Zones:$vsan_zone.active_zones
Status:
#end
"""

# commands impl

# show zone status vsan 11
def get_vsan_zone_status(vsan_id):
    vsan_zones = []

    # each is a zone summary like vsan id, name, active zone # ...
    zone_status_list = generate_all_zones_status()

    for vsan_zone in zone_status_list:
        if vsan_zone["vsan_id"] == vsan_id:
            vsan_zones.append(vsan_zone)

    if vsan_zones == []:
        print "%s is not configured" % vsan_id
        sys.exit(1)

    printTemplate(vsan_zones)

def get_zone_status():
    ## Where is generate_zones_info's defination?
    printTemplate(generate_zones_info())

# command: zone name Zone1 vsan 3
def zone_name(vsanid, zname):
    logger.info("Get zonesets from zone_name()...")
    vsans = simdb.get_zonesets()

    vsan = find_vsan(vsans, vsanid)
    if vsan == None:
        print >> sys.stderr, "not found vsan %s" % vsanid
        sys.exit(-1)

    zone = find_zone_by_name(vsan, zname)
    print "found zone %s" % zone

    if zone == None:
        # create one under default zoneset
        default_zset = get_default_zoneset(vsan)
        zone = {}
        zone["name"] = zname
        default_zset['zones'].append(zone)

        # write back to db
        print "vsans after add zone" % vsans
        logger.info("Write zonesets from zone_name...")
        simdb.write_zonesets(vsans)

    # dump zone params for member pwwn
    params = {'vsanid' : vsanid, 'zonename' : zname }
    simparam.dump(params)

# command: member pwwn 10:00:00:23:45:67:89:ab
def member_pwwn(pwwn):
    logger.info("Get zonesets from member_pwwn()...")
    params = simparam.load()

    vsans = simdb.get_zonesets()

    vsan = find_vsan(vsans, params['vsanid'])
    if vsan == None:
        print >> sys.stderr, "not found vsan %s" % vsanid
        sys.exit(-1)

    zone = find_zone_by_name(vsan, params['zonename'])
    if zone == None:
        print >> sys.stderr, "not found zone. vsan is %s, zone name is %s" \
        % (params['vsanid'], params['zonename'])
        sys.exit(-1)

    member = {'pwwn' : pwwn}
    if 'members' not in zone:
        zone['members'] = []
    if _is_member_existing(zone['members'], member):
        print 'Duplicate member'
        return

    # Add the given pwwn into the zoneset.
    zone['members'].append(member)
    # write back to db
    logger.info("Write zonesets from member_pwwn()...")
    simdb.write_zonesets(vsans)


def _is_member_existing(members, member):
    for port in members:
        if port['pwwn'] == member['pwwn']:
            return True
    return False

def member_alias(aliasInput):
    aliases = simdb.get_aliases()
    pwwn = alias.get_pwwn_by_alias(aliases, aliasInput)
    member_pwwn(pwwn)

# command: no zone name SDS_10_105_56_50_0090FA145151_7795_SPB3 vsan 12
def no_zone(name, vsanid):
    logger.info("Get zonesets from no_zone()...")
    vsans = simdb.get_zonesets()

    vsan = find_vsan(vsans, vsanid)
    if vsan == None:
        print >> sys.stderr, "not found vsan %s" % vsanid
        sys.exit(-1)

    remove_zone_by_name(vsan, name)
    # write back to db
    logger.info("Write zonesets from no_zone()...")
    simdb.write_zonesets(vsans)
    pass

def get_zone_by_pwwn(vsan_id, pwwn):
    logger.info("Get zonesets from get_zone_by_pwwn()...")
    vsan_zonesets = simdb.get_zonesets()
    zone_names = []
    for vsan in vsan_zonesets:
        if vsan["id"] == vsan_id:
            for zoneset in vsan["zonesets"]:
                if zoneset["active"] == "true":
                    zone_name = get_zone_name(zoneset["zones"],pwwn)
                    if zone_name != None and len(zone_name)>0:
                        zone_names.extend(zone_name)
    if len(zone_names)>0:
        nameSpace = {
            "vsan_id":vsan_id,
            "zone_names":zone_names,
            "pwwn":pwwn
        }
        t = airspeed.Template(show_pwwn_zone_tmpl)
        print t.merge(nameSpace)

def get_zone_detail(zone_name):
    logger.info("Get zonesets from get_zone_detail()...")
    vsan_zonesets = simdb.get_zonesets()
    for vsan in vsan_zonesets:
        for zoneset in vsan["zonesets"]:
            for zone in zoneset["zones"]:
                if zone["name"] == zone_name:
                    nameSpace = {"zone":zone,"vsan":vsan}
                    t = airspeed.Template(show_zone_name_tmpl)
                    print t.merge(nameSpace)

##########################################################
# private methods

def get_zone_name(zones, pwwn):
    zone_names = []
    for zone in zones:
        for member in zone["members"]:
            if member["pwwn"].lower() == pwwn.lower():
                zone_names.append(zone["name"])
    return zone_names

def get_zone_status_by_vsan(vsan):
    full_zoneset_number = 0
    full_zones = 0
    active_zoneset_name = ""
    active_zones = 0
    vsan_name = vsan["name"]
    for zoneset in vsan["zonesets"]:
        full_zoneset_number += 1
        if zoneset["active"] == "true":
            active_zoneset_name = zoneset["name"]
            zones = zoneset["zones"]
            for zone in zones:
                active_zones += 1
                full_zones += 1
        else:
            zones = zoneset["zones"]
            for zone in zones:
                full_zones += 1
    return full_zoneset_number, full_zones, active_zoneset_name, active_zones

def generate_all_zones_status():
    logger.info("Get zonesets from generate_all_zones_status()...")
    vsans = simdb.get_zonesets()
    zone_status_list = []
    for vsan in vsans:
        vsan_zone_item = {}
        vsan_zone_item["vsan_id"] = vsan["id"]
        vsan_zone_item["vsan_name"] = vsan["name"]
        (full_zoneset_number, full_zones, active_zoneset_name, active_zones) = get_zone_status_by_vsan(vsan)
        vsan_zone_item["full_zoneset_number"] = full_zoneset_number
        vsan_zone_item["full_zones"] = full_zones
        vsan_zone_item["active_zoneset_name"] = active_zoneset_name
        vsan_zone_item["active_zones"] = active_zones
        zone_status_list.append(vsan_zone_item)
    return zone_status_list

def remove_zone_by_name(vsan, zonename):
    for zset in vsan["zonesets"]:
        zones_in_cur_zoneset = zset["zones"]
        for z in zones_in_cur_zoneset:
            if z['name'] == zonename:
                zones_in_cur_zoneset.remove(z)

def printTemplate(vsan_zones):
    nameSpace = {'vsan_zones': vsan_zones}
    t = airspeed.Template(template_zone_status)
    print t.merge(nameSpace)


def find_vsan(vsans, vsanid):
    for vsan in vsans:
        if vsan['id'] == vsanid:
            return vsan
    return None

def find_zone_by_name(vsan, zname):
    for zset in vsan['zonesets']:
        for z in zset['zones']:
            if z['name'] == zname:
                return z
    return None

def find_zoneset(vsan, name):
    for zset in vsan['zonesets']:
        if zset['name'] == name:
            return zset
    return None

def get_default_zoneset(vsan):
    for zset in vsan['zonesets']:
        if zset['name'] == 'default':
            return zset
    return None

def get_zone_by_name(zname):
    vsans = simdb.get_zonesets()
    for vsan in vsans:
        for zset in vsan['zonesets']:
            for zone in zset['zones']:
                if zone['name'] == zname:
                    print "found"
                    nameSpace = {
                        'zone': zone,
                        'vsan_id': vsan['id'],
                    }
                    t = airspeed.Template(template_zone)
                    print t.merge(nameSpace)

#zone_name('1', "1234")
#member_pwwn('11:22:33:44:55:66')
