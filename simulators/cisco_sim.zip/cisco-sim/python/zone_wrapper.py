#!/usr/bin/python

import sys
from zone import *

args = []
for arg in sys.argv:
    args.append(arg)

print args

if args[1] == "name":  # zone name <zonset name> vsan <id>
    zone_name(args[4], args[2])
    
else:
    print "Wrong options"


