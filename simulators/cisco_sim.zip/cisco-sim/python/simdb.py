#!/usr/bin/python
import atexit
import json
import time
import os
import logutil
import fcntl

CISCO_SIM_HOME = os.environ['CISCO_SIM_HOME']
FCNS_DB = "%s/db/fcns.db" % CISCO_SIM_HOME
ZONESET_DB = "%s/db/zonesets.db" % CISCO_SIM_HOME
ZONESET_DBT = "%s/db/zonesets.dbt" % CISCO_SIM_HOME
VERSION_DB = "%s/db/version" % CISCO_SIM_HOME
SYSTEM_DB = "%s/db/system" % CISCO_SIM_HOME
ALIASES_DB = "%s/db/aliases.db" % CISCO_SIM_HOME
db_lock_file = "/tmp/simdb.lck"
logger = logutil.getLogger('ciscosim')

class FLock:

    def __init__(self, filename):
        self.filename = filename
        # This will create it if it does not exist already
        self.handle = os.open(filename, os.O_CREAT | os.O_TRUNC | os.O_WRONLY)

    # Bitwise OR fcntl.LOCK_NB if you need a non-blocking lock
    def lock(self):
        fcntl.flock(self.handle, fcntl.LOCK_EX)

    def unlock(self):
        fcntl.flock(self.handle, fcntl.LOCK_UN)

    def __del__(self):
        os.close(self.handle)

def lock():
    logger.info("Acquiring simdb lock...")
    while (os.path.isfile(db_lock_file) == True):
        logger.info("Simdb is already locked, waiting...")
        time.sleep(0.100)
    open(db_lock_file, 'w').close()
    logger.info("Get the simdb lock.")

def unlock():
    logger.info("Releasing simdb lock...")
    if(os.path.isfile(db_lock_file) == True):
        os.remove(db_lock_file)
        logger.info("The simdb lock is released.")

def get_file(file_name):
    try:
        file = open(file_name, 'r')
        for line in file:
            print line.rstrip()
    finally:
        file.close()

def get_fcns():
    fcns_file = open(FCNS_DB, 'r')
    fcns = json.load(fcns_file)
    fcns_file.close()
    return fcns

def update_fcns(data):
    try:
        s = json.dumps(data,
            sort_keys=True, indent=4, separators=(',', ': '))

        f = open(FCNS_DB, 'w')
        f.write(s)
    finally:
        f.close()

def get_zonesets():
    logger.info("get_zonesets() starts...")
    flock = FLock("/tmp/lock_name.tmp")
    flock.lock()
    #use hook function to release lock file to avoid program abnormal exit
    atexit.register(flock.unlock)
    try:
        zonesets_file = open(ZONESET_DB, 'r')
        zonesets = json.load(zonesets_file)
    finally:
        zonesets_file.close()
        flock.unlock()
    logger.info("get_zonesets() end")
    return zonesets

def get_aliases():
    f = open(ALIASES_DB,"r")
    aliases = json.load(f)
    f.close()
    return aliases

def write_zonesets(data):
    logger.info("write_zonesets() starts...")
    flock = FLock("/tmp/lock_name.tmp")
    flock.lock()
    #use hook function to release lock file to avoid program abnormal exit
    atexit.register(flock.unlock)
    try:
        s = json.dumps(data,
            sort_keys=True, indent=4, separators=(',', ': '))
        z = open(ZONESET_DBT, 'w')
        z.write(s)
    finally:
        z.flush()
        z.close()
    os.rename(ZONESET_DBT, ZONESET_DB)
    time.sleep(0.100)
    flock.unlock()
    logger.info("write_zonesets() end")

def write_aliases(aliases):
    logger.info("write_aliases() starts...")
    lock()
    atexit.register(unlock)
    try:
        s = json.dumps(aliases,
            sort_keys=True, indent=4, separators=(',',': '))
        f = open(ALIASES_DB, 'w')
        f.write(s)
    finally:
        f.close()
        unlock()

def get_version():
    get_file(VERSION_DB)

def get_system():
    get_file(SYSTEM_DB)

