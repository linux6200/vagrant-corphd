#!/usr/bin/python

import sys
import logutil
from show import *
from alias import *

logger = logutil.getLogger('ciscosim')

args = []
for arg in sys.argv:
    args.append(arg)

if args[1] == "fcdomain":
    show_fcdomain()
elif args[1] == "system":
    show_system()
elif args[1] == "version":
    show_version()
elif args[1] == "fcns":
    show_fcnsdb()

elif args[1] == "zone":
    if args[2] == "status" and len(args) == 3:
        show_zone_status()
    elif args[2] == "status" and args[3] == "vsan":
        show_vsan_zone_status(args[4])
    elif args[2] == "vsan":
        show_zone_vsan(args[3])
    elif args[2] == "member" and args[3] =="pwwn" and args[5]=="active":
	show_vsan_pwwn_zone(args[7],args[4])
    elif args[2] == "member" and args[3] =="pwwn":
        show_vsan_pwwn_zone(args[6],args[4])
    elif args[2] == "name":
        show_zone_by_name(args[3])

elif args[1] == "zoneset":
    if args[2] == "active":
        if len(args) == 3:
            show_active_zoneset()
        elif args[3] == "vsan":
            show_vsan_active_zoneset(args[4])

    elif args[2] == "vsan":
        show_vsan_zoneset(args[3])
elif args[1] == "vsan":
    show_vsan()
elif args[1]=="device-alias" and args[2]=="database":
    show_alias()
else:
    print "Wrong options"

logger.info("The args are: %s" % args)
