#!/usr/bin/python

import sys
from zone import *

args = []
for arg in sys.argv:
    args.append(arg)


if args[1] == "name":  # zonset name <zonset name> vsan <id>
    config_zoneset(args[2], args[4])
elif args[1] == "activate":
    # zoneset activate name Zoneset_12 vsan 12
    activate_zoneset(args[3], args[5])
    
else:
    print "Wrong options"


