#!/usr/bin/python

import sys
from alias import *

args = []
for arg in sys.argv:
    args.append(arg)
if args[1]=="name" and args[3]=="pwwn":  # device-alias name {0} pwwn {1} 
    add_alias(args[2], args[4])
elif args[1]=="create": #used to create numerous alias for scale testing, will not be called by ViPR
    create_fake_alias(int(args[2]))
else:
    print "Wrong options"
