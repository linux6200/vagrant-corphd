""" The logging utility used by cisco-simulator.

Created by Max Huang on Jan 26th, 2015.

Originally the cisco-simulator did not have logging mechanism in the python
scripts. This makes it very difficult to debug issues happened in them. Now
we add it by introducing this logutil file and you use it in any script you
want to add logging items. Basically this is just a wrapper of the standard
python logger(https://docs.python.org/2/library/logging.html#logging.Logger)
Only two steps are required to use it. First, at the beginning of a python
script file write the following lines to create a logger:

    import logutil
    logger = logutil.getLogger("ciscosim")

Second, use the logger to write log item:

    logger.info("The args are: %s" % args)

As you can see in this file, it uses "config/logging.conf" file to configure
the logging behaviour. In this configuration file, you can find the logging
file is "logs/ciscosim_python.log".
"""

import os
import logging
import logging.config

def getLogger(name = 'ciscosim'):
  path = os.path.dirname(os.path.realpath(__file__))
  logging.config.fileConfig("%s/../config/logging.conf" % path)
  logger = logging.getLogger(name)
  return logger
