import sys, airspeed, simdb, logutil

logger = logutil.getLogger('ciscosim')

template_show_alias = """
#foreach ($alias in $aliases)
device-alias name $alias.name pwwn $alias.pwwn
#end## 

    Total number of entries = $size 
"""

def get_wwns():
    fcns = simdb.get_fcns()
    wwns = []
    for vsan in fcns["vsans"]:
        for port in vsan["ports"]:
            wwn = port["nwwn"]
            wwns.append(wwn)
    return wwns

#note that we can't use fake wwn
def create_fake_alias(num):
    wwns = get_wwns()
    if len(wwns) < num:
        print "you want to create " + str(num) + " alias" + ", but only " +  str(len(wwns)) + " ports exist"
        exit(-1)
    fake_alias_prefix="fack_alias_"
    aliases = simdb.get_aliases()
    for i in range(num):
        name = fake_alias_prefix + str(i)
        print "create alias " + name + ",pwwn:" + wwns[i-1] 
        alias = {'name':name, "pwwn":wwns[i-1]}
        aliases.append(alias)
    logger.info("write aliases...")
    simdb.write_aliases(aliases)

#device-alias name {0} pwwn {1}
def add_alias(name, pwwn):
    aliases = simdb.get_aliases()
    exist = find_alias(aliases, name)
    if exist:
        print "Device Alias already present"
        sys.exit(-1)
    alias = {'name':name, "pwwn":pwwn}
    aliases.append(alias)
    logger.info("write aliases...")
    simdb.write_aliases(aliases)

def remove_alias(name):
    aliases = simdb.get_aliases()
    exist = find_alias(aliases, name)
    if not exist:
        print "Device Alias not present"
        sys.exit(-1)
    for alias in aliases:
        if alias["name"] == name:
            aliases.remove(alias)
    logger.info("write aliases...")
    simdb.write_aliases(aliases)

def find_alias(aliases, name):
    for alias in aliases:
        if alias["name"] == name:
            return True
    return False

def show_alias():
    aliases = simdb.get_aliases()
    nameSpace = {"aliases": aliases,
                 "size": len(aliases)}
    t = airspeed.Template(template_show_alias)
    print t.merge(nameSpace)

def get_alias_by_pwwn(aliases, pwwn):
    for alias in aliases:
        if alias["pwwn"]==pwwn:
            return "[" + alias["name"] + "]"
    return ""

def get_pwwn_by_alias(aliases, alias_name):
    for alias in aliases:
        if alias["name"] == alias_name:
            return alias["pwwn"]
    return ""
