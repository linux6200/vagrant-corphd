import json
import os

# If you want to do test on it, you may need to make the para_file name be a constant path
_param_file = '/tmp/params_%s' % os.getppid()

# dump parameters to file as the context for next command
def dump(params):

    s = json.dumps(params, 
        sort_keys=True, indent=4, separators=(',', ': '))

    f = open(_param_file, 'w')
    f.write(s)
    f.close() 

# return a map of parameters
def load():

    f = open(_param_file, 'r+')
    params = json.load(f)
    f.close() 
    return params
