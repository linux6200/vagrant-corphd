#!/usr/bin/python

import sys
from zone import *
from alias import *
args = []
for arg in sys.argv:
    args.append(arg)

if args[1] == "zone":  # no zone name <zonset name> vsan <id>
        no_zone(args[3], args[5])
elif args[1]=="device-alias" and args[2]=="name":
    remove_alias(args[3])
else:
    print "Not supported arguments"


