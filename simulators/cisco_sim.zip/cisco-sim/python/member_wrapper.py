#!/usr/bin/python

import sys
from zone import *

args = []
for arg in sys.argv:
    args.append(arg)

if args[1] == "pwwn":
    member_pwwn(args[2])
elif args[1] == "device-alias":
    member_alias(args[2])
else:
    member_zone_to_zoneset(args[1])
    


