import airspeed
from simdb import *
from alias import * 

template = """
#foreach ($fcns_item in $fcns)
------------------------
VSAN:$fcns_item.vsan_id     FCID:$fcns_item.domain_id
------------------------
port-wwn (vendor)           :$fcns_item.port_wwn 
                            $fcns_item.alias
node-wwn                    :$fcns_item.node_wwn
class                       :3
node-ip-addr                :0.0.0.0
ipa                         :ff ff ff ff ff ff ff ff
fc4-types:fc4_features      :scsi-fcp
symbolic-port-name          :CLARiiON::::SPB00::FC::::::
symbolic-node-name          :CLARiiON::::SPB::FC::::::
port-type                   :N
port-ip-addr                :0.0.0.0
fabric-port-wwn             :$fcns_item.fabric_port_wwn
hard-addr                   :0x000000
permanent-port-wwn (vendor) :$fcns_item.permanent_port_wwn (Clariion)
Connected Interface         :$fcns_item.connected_interface
Switch Name (IP address)    :$fcns_item.switch_name
#end 
"""

def show_fcns():
    fcns_db = get_fcns() 
    fcns = []
    vsans = fcns_db["vsans"]
    
    interface_idx = 1
    alises = get_aliases()
    for vsan in vsans:

        ports = vsan["ports"]

        for port in ports:
            fcns_item = {}
            fcns_item["vsan_id"] = vsan["id"]
            fcns_item["domain_id"] = vsan["domain_id"]
            fcns_item["port_wwn"] = port["pwwn"]
            fcns_item["node_wwn"] = port["nwwn"]
            fcns_item["fabric_port_wwn"] = vsan["fabric_name"]
            fcns_item["permanent_port_wwn"] = port["pwwn"]
            fcns_item["connected_interface"] = "fc1/%d" % interface_idx
            fcns_item["switch_name"] = fcns_db["name"]
            fcns_item["alias"] =get_alias_by_pwwn(alises, fcns_item["port_wwn"])
            fcns.append(fcns_item) 

            interface_idx += 1

    nameSpace = {'fcns': fcns}
    t = airspeed.Template(template)
    print t.merge(nameSpace)
   
