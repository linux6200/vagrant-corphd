#!/usr/bin/python

import airspeed
from simdb import *
from fcns import *
from zone import *

fcdomain_tmpl = """
#foreach ($vsan in $vsans)##
VSAN $vsan.id
The local switch is the Principal Switch.

Local switch run time information:
        State: Stable
        Local switch WWN:    $vsan.local_switch
        Running fabric name: $vsan.fabric_name
        Running priority: 128
        Current domain ID: $vsan.domain_id

Local switch configuration information:
        State: Enabled
        FCID persistence: Enabled
        Auto-reconfiguration: Disabled
        Contiguous-allocation: Disabled
        Configured fabric name: 20:01:00:05:30:00:28:df
        Optimize Mode: Disabled
        Configured priority: 128
        Configured domain ID: 0x00(0) (preferred)

Principal switch run time information:
        Running priority: 2

Interface               Role          RCF-reject
----------------    -------------    ------------
fc1/47              Upstream         Disabled
fc1/48              Non-principal    Disabled
----------------    -------------    ------------
#end 
"""

show_zone_vsan_tmpl = """
#foreach ($zone in $zones)
zone name $zone.name vsan $vsan.id
  #foreach ($pwwn in $zone.members)
  pwwn $pwwn
#end
"""

show_vsan_tmpl = """
#foreach ($vsan in $vsans)
vsan $vsan.id information
         name:$vsan.name  state:active
         interoperability mode:default
         loadbalancing:src-id/dst-id/oxid
         operational state:down
#end
"""

def show_fcdomain():

    fcns = get_fcns()
    nameSpace = {'vsans': fcns["vsans"]}
    t = airspeed.Template(fcdomain_tmpl)

    print t.merge(nameSpace)
def show_vsan():
    fcns = get_fcns()
    nameSpace = {'vsans': fcns["vsans"]}
    t = airspeed.Template(show_vsan_tmpl)
    print t.merge(nameSpace)
def show_fcnsdb():
    # show all vsans

    # print each port with port wwn, node wwn, interface, switch name
    show_fcns() 
	
def show_version():
    get_version()

def show_system():
    get_system()

# show zone status
# show zone status vsan5
def show_zone_status(): 
    get_zone_status()

def show_vsan_zone_status(vsan_id):
    get_vsan_zone_status(vsan_id)

# show zoneset vsan5
def show_vsan_zoneset(vsan_id):
    get_vsan_zoneset(vsan_id)

def show_active_zoneset():
    get_active_zoneset()

# show zoneset active vsan5
def show_vsan_active_zoneset(vsan_id):
    get_vsan_active_zoneset(vsan_id)

# show zone vsan 11
def show_zone_vsan(vsanid):
    get_vsan_zoneset(vsanid)

def show_zone_by_name(zname):
    get_zone_by_name(zname)

# show zone member pwwn {0} active vsan {1}
def show_vsan_pwwn_zone(vsan_id, pwwn):
    get_zone_by_pwwn(vsan_id, pwwn)

#show zone name ${0}
def show_zone_name(zone_name):
    get_zone_detail(zone_name)
